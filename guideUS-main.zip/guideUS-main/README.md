# guideUS
## 성균관대학교 알고리즘 플젝

## 6조 코딩해조
DP (Dynamic Programming)을 이용한 효율적인 루트 검색 프로그램입니다!
<img src="https://user-images.githubusercontent.com/78555268/144193600-514a70e6-066b-445d-b32b-5d200135d808.gif">
<img src="https://user-images.githubusercontent.com/78555268/144193657-860603a5-3db2-48ce-89f1-54733ee02f4d.gif">

만든이
김태완 김연준 한창희 허민석
